let item="";
let Drawitem="";
let specialObjName;
let hover=[];
let shape=document.getElementById("shape")
let files = document.getElementById("files");

//-----------------Adding Object------------------------------------
function
addObj(obj,name)
{
collide=false
range.style.height="100px"
shape.style.height="0px"
switch(obj){
case "Circle":
Drawitem="Circle"
range.innerHTML=
'Radius:<input class="inputWidth" oninput="inputter(this,`radius`)" ontouchstart="inputts(this,event)" ontouchmove="inputtm(this,event,`radius`)" ontouchend="inputte(this,event)" value="0" ><br>'+
'Collusion:<button onclick="collusion(this)">false</button><br>'+
'Name:<input class="inputWidth" oninput="changeName(this)" ><br>'+
'<button onclick="addObj(`Close`)">Cancle</button>'
break;
case "Road":
Drawitem="Road"
range.innerHTML=
'<button onclick="Connect()">Connect</button>'+
'<button onclick="Undo()">Undo</button><br>'
array.push(new RoadSegment(2,"white",[20,20]) )
break;
case "Rectangle":
Drawitem="Rectangle"
range.innerHTML=
'Height:<input class="inputWidth" oninput="inputter(this,`height`)" ontouchstart="inputts(this,event)" ontouchmove="inputtm(this,event,`height`)" ontouchend="inputte(this,event)" value="0" ><br>'+
'Width:<input class="inputWidth" oninput="inputter(this,`width`)" ontouchstart="inputts(this,event)" ontouchmove="inputtm(this,event,`width`)" ontouchend="inputte(this,event)" value="0" ><br>'+
'Rotate:<input class="inputWidth" oninput="inputter(this,`rotate`)" ontouchstart="inputts(this,event)" ontouchmove="inputtm(this,event,`rotate`)" ontouchend="inputte(this,event)" value="0" ><br>'+
'Name:<input class="inputWidth" oninput="changeName(this)" ><br>'+
'Collusion:<button onclick="collusion(this)">false</button><br>'+
'<button onclick="addObj(`Close`)">Cancle</button>'
break;
case "Image":
Drawitem="Image"
range.innerHTML=
'Height:<input class="inputWidth" oninput="inputter(this,`height`)" ontouchstart="inputts(this,event)" ontouchmove="inputtm(this,event,`height`)" ontouchend="inputte(this,event)" value="0" ><br>'+
'Width:<input class="inputWidth" oninput="inputter(this,`width`)" ontouchstart="inputts(this,event)" ontouchmove="inputtm(this,event,`width`)" ontouchend="inputte(this,event)" value="0" ><br>'+
'Rotate:<input class="inputWidth" oninput="inputter(this,`rotate`)" ontouchstart="inputts(this,event)" ontouchmove="inputtm(this,event,`rotate`)" ontouchend="inputte(this,event)" value="0" ><br>'+
'Name:<input class="inputWidth" oninput="changeName(this)" ><br>'+
'Collusion:<button onclick="collusion(this)">false</button><br>'+
'Src:<input class="inputWidth" oninput="inputData(this,`src`)"><br>'+
'<button onclick="addObj(`Close`)">Cancle</button>'
break;
case "Polygon":
Drawitem="Polygon"
array.push(new Polygon(0,0))
range.innerHTML=
'Data:<input class="inputWidth" oninput="inputData(this,`data`)" value="0" ><br>'+
'Stroke:<input class="inputWidth" oninput="inputData(this,`stroke`)" value="0" ><br>'+
'Fill:<input class="inputWidth" oninput="inputData(this,`fill`)" value="0" ><br>'+
'Name:<input class="inputWidth" oninput="changeName(this)" ><br>'+
'Collusion:<button onclick="collusion(this)">false</button><br>'+
'<button onclick="Undo()">Undo</button><br>'+
'<button onclick="inputData(this,`clp`)">Closepath</button><br>'+
'<button onclick="addObj(`Close`)">Cancle</button>'
break;
case "Delete":
Drawitem="Delete"
range.style.height="0px"
Dele()
break;
case "Close":
Drawitem="None"
specialObjName="None"
range.style.height="0px"
break;
case "Other":
Drawitem="Other";
specialObjName=name
range.innerHTML=
'<button onclick="addObj(`Close`)">Cancle</button>'
break;
default:
Drawitem="None"
range.style.height="0px"
}
}

//-----------------Changing Property------------------------------------

function
changeName(input){
name=input.value
}

function
collusion(itself){
if(collide){
collide=false
itself.innerHTML=false
}else{
collide=true
itself.innerHTML=true
}
}

//-----------------Deleting Object------------------------------------
let deleteCir=[]
function
Dele()
{
deleteCir=[]
for(let i=0;i<circle.length;i++){
deleteCir.push(new Circle(circle[i].x+offSet.x,circle[i].y+offSet.y,30,"red"))
}
for(let i=0;i<rect.length;i++){
deleteCir.push(new Circle(rect[i].x+offSet.x,rect[i].y+offSet.y,30,"red"))
}
for(let i=0;i<image.length;i++){
deleteCir.push(new Circle(image[i].x+offSet.x,image[i].y+offSet.y,30,"red"))
}
}

//-----------------Connect Road------------------------------------
let con=true
function
Connect()
{
if(con){
Drawitem="Connect"
deleteCir=[]
for(let i=0;i<road[0].length;i++){
deleteCir.push(new Circle(road[0][i].x+offSet.x,road[0][i].y+offSet.y,30,"red"))
}
con=false
}else{
deleteCir=[]
con=true
}
}

//--------------Input Data-------------------------------------------------------------------------------------------------------------------------------------------------
let radi=10,roadWidth=100,height=100,width=100,rotate=0,src="file:///sdcard/Pds_engin/Logo.png",data=[]
function
inputData(input,property)
{
switch(Drawitem){
case "Circle":
radi=input.value
break;
case "Road":
roadWidth=input.value
break;
case "Rectangle":
switch(property){
case 'height':
height=input.value
break;
case 'width':
width=input.value
break;
case 'rotate':
rotate=input.value
break;
}
break;
case "Image":
switch(property){
case 'height':
height=input.value
break;
case 'width':
width=input.value
break;
case 'rotate':
rotate=input.value
break;
case 'src':
src=input.value
break;
}
break;
case "Polygon":
switch(property){
case 'data':
array[array.length-1].data=input.value
break;
case 'fill':
array[array.length-1].fill=input.value
break;
case 'stroke':
array[array.length-1].color=input.value
break;
case 'clp':
if(array[array.length-1].closePath){
array[array.length-1].closePath=false
input.innerHTML="ClosePath"
}else{
array[array.length-1].closePath=true
input.innerHTML="UnClosePath"
}
break;
}
break;
}
}

//------------function for scrole input--------------------------------
let set=10
let XX,YY;
function
inputter(input,property){
set=input.value
if(input.value==""){
set=0
input.value=0
}
inputData(input,property)
}

function
inputts(input,e){
XX = e.touches[0].clientX;
YY = e.touches[0].clientY;
set=input.value
}

function
inputtm(input,e,property=""){
let Xm = e.touches[0].clientX;
let Ym = e.touches[0].clientY;
let dist=Math.sqrt((XX-Xm)**2+(YY-Ym)**2)
if(XX>Xm){
let add=parseInt(set)-dist
if(add<0&&property!="rotate"){
add*=-1
}
input.value=add
}else{
let add=parseInt(set)+dist
input.value=add
}
inputData(input,property)
}

function
inputte(input,e){
if (e.changedTouches.length > 0) {
let Xe = e.changedTouches[0].clientX;
let Ye = e.changedTouches[0].clientY;
set=input.value
}
}
//---------chooseing Option-------------------------------------------
function
Option(box)
{
if(box.getAttribute("id")=="object" && box.style.height=="0px"){
ani=false
}else{
ani=true
animation()
}

if(box.style.height=="180px"){
box.style.height="0px"
box.style.borderBottom="0px solid white"
}else{
for(let i=0;i<hover.length;i++){
if(box==hover[i]){
}else{
hover[i].style.height="0px"
hover[i].style.borderBottom="0px solid white"
}
}
box.style.height="180px"
box.style.borderBottom="1px solid white"
}

}

//-------------------color Input----------------------------------------

let color=document.getElementById("color")
let red=document.getElementById("red")
let green=document.getElementById("green")
let blue=document.getElementById("blue")
let opacity=document.getElementById("opacity")
let colorBox=document.getElementById("colorBox")

red.addEventListener("input",()=>{
color.value="rgba("+red.value+","+green.value+","+blue.value+","+opacity.value/10+")"
colorBox.style.backgroundColor=color.value
})
green.addEventListener("input",()=>{
color.value="rgba("+red.value+","+green.value+","+blue.value+","+opacity.value/10+")"
colorBox.style.backgroundColor=color.value
})
blue.addEventListener("input",()=>{
color.value="rgba("+red.value+","+green.value+","+blue.value+","+opacity.value/10+")"
colorBox.style.backgroundColor=color.value
})
opacity.addEventListener("input",()=>{
color.value="rgba("+red.value+","+green.value+","+blue.value+","+opacity.value/10+")"
colorBox.style.backgroundColor=color.value
})
color.addEventListener("input",()=>{
colorBox.style.backgroundColor=color.value
})
color.addEventListener("input",()=>{
colorBox.style.backgroundColor=color.value
})

//---------------------other-------------------------------------------------
function
offClick(){
event.stopPropagation()
}

let ids=["object","exports","shape","colorChoos","setting"]
for(let i=0;i<5;i++){
hover.push(document.getElementById(ids[i]))
}


//--------------Copy to Clipbord && Download------------------------------------

function
GetCoad()
{

var text = `
let array= ${JSON.stringify(array)};
let roadObj = ${JSON.stringify(road)};

let obj=[]

for(let i=0;i<array.length;i++){
let ele=array[i]
if(ele.r){
obj.push(new Circle(ele.x,ele.y,ele.r,ele.color,ele.collide,ele.name))
}else if(ele.data && !ele.src){
obj.push(new Polygon(ele.x,ele.y,ele.data))
}else if(ele.src){

obj.push(new ImgObj(ele.x,ele.y,'./'+ele.src,ele.width,ele.height))
}else{
obj.push(new Rect(ele.x,ele.y,ele.color,ele.width,ele.height))
}
}


let road
if(roadObj!=[]){
road=[]
road[0]=roadObj[0].map(obj=>new Circle(obj.x,obj.y,obj.r,obj.color))
road[1]=roadObj[1]
road[2]=roadObj[2].map(obj=>new Circle(obj.x,obj.y,obj.r,obj.color))
road[3]=roadObj[3]
seg=new RoadSegment(road[3],"grey")
divider=new RoadSegment(2,"white",[20,20])
}`;
return text;
}

function
Download()
{
GetCoad()
var blob = new Blob([GetCoad()], { type: 'text/plain' });
var downloadLink = document.createElement('a');
downloadLink.href = window.URL.createObjectURL(blob);
downloadLink.download = 'script.js';
downloadLink.click();
}

let Coad=document.getElementById("Coad")
function 
Copy(){
let coad=GetCoad()
navigator.clipboard.writeText(GetCoad());
Coad.innerHTML=coad
}

//----------------input File-------------------------------------------



function
inputFiletext(inputElement){
Allimage.push({img:inputElement.value, select:false });
UpdateImg()
};



function
UpdateImg(){
files.innerHTML=""
let color="black"
Allimage.forEach((image,i)=>{
if(image.select){
color="gold"
}else{
color="black"
}
files.innerHTML+=`<div id="img" style="background-color:${color};" onclick="imgSelect(${i})" >
<img id="imgSrc" src="${image.img}" height="100px" width="100px"  >
<div id="cross" style="background-color:${color};" onclick="delImg(${i})">x</div>
</div>`
})
}

function
delImg(i){
Allimage.splice(i,1)
UpdateImg()
}

function
imgSelect(i){
Allimage.forEach((image)=>{
if(image.select){
image.select=false
}
})
Allimage[i].select=true
UpdateImg()
src=Allimage[i].img
}





const AllFiles = [];
function inputFile(inputElement) {
if (inputElement.files.length > 0) {
const file = inputElement.files[0];
const fileType = file.type;

if (fileType === "application/zip") {
const zip = new JSZip();
zip.loadAsync(file)
.then(function (zipContent) {
zipContent.forEach(function (relativePath, zipEntry) {
AllFiles.push(zipEntry.name);
});
alert("All file names:\n" + JSON.stringify(AllFiles, null, 2));

for(let i=1;i<AllFiles.length;i++){
Allimage.push({ img:AllFiles[i], select: false });
}
UpdateImg()
})
.catch(function (err) {
alert("Error extracting zip file: " + err.message);
});
} else {
alert("Please upload a valid ZIP file.");
}
}
}





files.addEventListener("change",function(){
inputFile(this); 
});
/*
let classMap={}

function
addSpecialObj(Path){
if(Path){
let hold=document.getElementById("specialObj")
let script=document.getElementById("script")
script.innerHTML+=
`<script type="text/javascript" src="${Path.value}"></script>`

let split=Path.value.split("/")
let name=split[split.length-1].split(".")[0]
hold.innerHTML+=`<span onclick="addObj('Other','${name}')">${name}</span><hr>`;

classMap[name]=eval(name)

importedObj[name]=classMap[name](canvas.width/2,canvas.height/2);
}
}
*/

let classMap = {}; // To store the dynamically loaded classes


function addSpecialObj(Path) {
  if (Path) {
    // Create and append a new <script> element for the dynamic script
    const script = document.createElement("script");
    script.type = "text/javascript";
    script.src = Path.value;

    script.onload = () => {
      // Extract the class name from the file path
      const split = Path.value.split("/");
      const name = split[split.length - 1].split(".")[0];

      // Add a button or clickable element for the object
      const hold = document.getElementById("specialObj");
      hold.innerHTML += `<span onclick="addObj('Other', '${name}')">${name}</span><hr>`;

      // Add the class to classMap and create an instance
      if (window[name]) {
        classMap[name] = window[name];
        importedObj[name] = new classMap[name](canvas.width / 2, canvas.height / 2);
      } else {
        alert(`Class "${name}" could not be found.`);
      }
    };

    script.onerror = () => {
      alert(`Failed to load script from: ${Path.value}`);
    };

    // Append the script to the document
    document.body.appendChild(script);
  }
}