class Camera{
constructor(x,y){
this.x=x;
this.y=y;
this.initialPo={X:x,Y:y}
this.range={from:{x:-700,y:-700},to:{x:700,y:700}};
this.Img=new Image();
this.Img.src=src;
this.Img.height=100;
this.Img.width=100;
}

draw(ctx,offSet,player=false)
{
if(player){
}else{
this.x=this.initialPo.X-offSet.x;
this.y=this.initialPo.Y-offSet.y;
}

ctx.save()
ctx.translate(this.x,this.y)
ctx.beginPath()
ctx.drawImage(this.Img,-this.Img.width/2,-this.Img.height/2,this.Img.width,this.Img.height)
ctx.restore()
}
}