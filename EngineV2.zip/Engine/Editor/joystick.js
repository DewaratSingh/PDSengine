class JoyStick{
constructor(id,height){
this.tag=document.getElementById(id)
this.tag.innerHTML=`
<svg style='border-radius:50%;position:fixed;height:${height};width:${height};background-color:grey;'>
<circle id='cir'  r='20' cx='60' cy='60' fill='white'></circle>
</svg>
`
this.cir=document.getElementById("cir")
this.event()
}

event(){
this.cir.addEventListener("touchmove", (e) => {
e.preventDefault();
const touch = e.touches[0];
const x = touch.clientX;
const y = touch.clientY;
let svg= this.tag.getBoundingClientRect();
this.cir.setAttribute('cx',x-svg.left)
this.cir.setAttribute('cy',y-svg.top)
});
this.cir.addEventListener("touchend", (e) => {
this.cir.setAttribute('cx',60)
this.cir.setAttribute('cy',60)
});
}

vector() {
let x = 60 - this.cir.getAttribute("cx");
let y = 60 - this.cir.getAttribute("cy");
let angle = Math.atan2(y, x);
if(x==0&&y==0){
return createVector(0,0);
}else{
return createVectorWithAngle(angle);
}
}
}

